/*

2012/06/22	Eric.Berg@usa.net

A simple LoadRunner script template that can be used to deploy files, 
run command line or silent install using a LoadRunner agent and access

