vuser_init()	//using vuser_init to run once
{
	
	system("copy hosts.txt C:\WINDOWS\system32\drivers\etc\hosts >> c:\\commandLine.log");

	return 0;
}
